<footer></footer>

</body>

<script src="../view/js/style.js"></script>

</html>